export declare class KafkaModule {
}
