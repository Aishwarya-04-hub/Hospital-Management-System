export declare class AppointmentsModule {
}
