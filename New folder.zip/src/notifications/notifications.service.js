"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var NotificationsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationsService = void 0;
const common_1 = require("@nestjs/common");
const appointments_service_1 = require("../appointments/appointments.service");
const kafka_service_1 = require("../kafka/kafka.service");
let NotificationsService = NotificationsService_1 = class NotificationsService {
    kafka;
    logger = new common_1.Logger(NotificationsService_1.name);
    sent = [];
    constructor(kafka) {
        this.kafka = kafka;
    }
    async onModuleInit() {
        await this.kafka.subscribe(appointments_service_1.APPOINTMENT_CREATED_TOPIC, 'notification-group', (e) => this.handle(e));
    }
    handle(event) {
        const message = `Hi ${event.patientName}, your appointment with ${event.doctorName} is booked for ${event.date}.`;
        this.logger.log(`[EMAIL to ${event.patientEmail}] ${message}`);
        this.sent.push({ to: event.patientEmail, message, appointmentId: event.appointmentId, at: new Date() });
    }
    list() { return this.sent; }
};
exports.NotificationsService = NotificationsService;
exports.NotificationsService = NotificationsService = NotificationsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [kafka_service_1.KafkaService])
], NotificationsService);
