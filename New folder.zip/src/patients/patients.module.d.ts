export declare class PatientsModule {
}
