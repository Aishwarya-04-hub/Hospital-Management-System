import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { Patient, PatientSchema } from './patient.schema';
import { PatientsController } from './patients.controller';
import { PatientsService } from './patients.service';

@Module({ imports: [MongooseModule.forFeature([{ name: Patient.name, schema: PatientSchema }])], controllers: [PatientsController], providers: [PatientsService], exports: [MongooseModule], })
export class PatientsModule {}