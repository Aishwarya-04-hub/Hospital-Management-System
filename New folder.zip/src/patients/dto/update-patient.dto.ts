import { PartialType } from "@nestjs/mapped-types";
import { CreatePatientDto } from './create-patient.dto';
import { CreateDoctorDto } from "../../doctors/dto/create-doctor.dto";
export class UpdatePatientDto extends
PartialType(CreateDoctorDto){}