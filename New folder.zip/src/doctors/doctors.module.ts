import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { Doctor, DoctorSchema } from './doctor.schema';
import { DoctorsController } from './doctors.controller';
import { DoctorsService } from './doctors.service';

@Module({ imports: [MongooseModule.forFeature([{ name: Doctor.name, schema: DoctorSchema }])], controllers: [DoctorsController], providers: [DoctorsService], exports: [MongooseModule], })
export class DoctorsModule {}