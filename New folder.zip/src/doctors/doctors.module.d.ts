export declare class DoctorsModule {
}
